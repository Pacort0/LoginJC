package com.example.miprimeraaplicacion

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class pausa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pausa)
    }

    override fun onResume() {
        super.onResume()
        val usuario = intent.getStringExtra("usuario").toString()
        val intent = Intent(this , Bienvenida::class.java)
        intent.putExtra("usuario", usuario)
        startActivity(intent)
    }
}